/*
 * Copyright 2014 Ankush Sachdeva
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package github.ankushsachdeva.emojicon;

import android.content.Context;
import android.text.Spannable;
import android.util.SparseIntArray;

/**
 * @author Hieu Rocker (rockerhieu@gmail.com)
 */
public final class EmojiconHandler {
    private EmojiconHandler() {
    }

    private static final SparseIntArray sEmojisMap = new SparseIntArray(846);
    private static final SparseIntArray sSoftbanksMap = new SparseIntArray(471);

    static {

        sEmojisMap.put(0x0501, R.drawable.tt0501);
        sEmojisMap.put(0x0502, R.drawable.tt0502);
        sEmojisMap.put(0x0503, R.drawable.tt0503);
        sEmojisMap.put(0x0504, R.drawable.tt0504);
        sEmojisMap.put(0x0505, R.drawable.tt0505);
        sEmojisMap.put(0x0506, R.drawable.tt0506);
        sEmojisMap.put(0x0507, R.drawable.tt0507);
        sEmojisMap.put(0x0508, R.drawable.tt0508);
        sEmojisMap.put(0x0509, R.drawable.tt0509);
        sEmojisMap.put(0x0510, R.drawable.tt0510);

        //Cat
        sEmojisMap.put(0x0201, R.drawable.tt0201);
        sEmojisMap.put(0x0202, R.drawable.tt0202);
        sEmojisMap.put(0x0203, R.drawable.tt0203);
        sEmojisMap.put(0x0204, R.drawable.tt0204);
        sEmojisMap.put(0x0205, R.drawable.tt0205);
        sEmojisMap.put(0x0206, R.drawable.tt0206);
        sEmojisMap.put(0x0207, R.drawable.tt0207);
        sEmojisMap.put(0x0208, R.drawable.tt0208);
        sEmojisMap.put(0x0209, R.drawable.tt0209);
        sEmojisMap.put(0x0210, R.drawable.tt0210);

        //Vdomax

        sEmojisMap.put(0x0301, R.drawable.tt0301);
        sEmojisMap.put(0x0302, R.drawable.tt0302);
        sEmojisMap.put(0x0303, R.drawable.tt0303);
        sEmojisMap.put(0x0304, R.drawable.tt0304);
        sEmojisMap.put(0x0305, R.drawable.tt0305);
        sEmojisMap.put(0x0306, R.drawable.tt0306);
        sEmojisMap.put(0x0307, R.drawable.tt0307);
        sEmojisMap.put(0x0308, R.drawable.tt0308);
        sEmojisMap.put(0x0309, R.drawable.tt0309);
        sEmojisMap.put(0x0310, R.drawable.tt0310);

        //TattossEmogi
        sEmojisMap.put(0x0401, R.drawable.tt0401);
        sEmojisMap.put(0x0402, R.drawable.tt0402);
        sEmojisMap.put(0x0403, R.drawable.tt0403);
        sEmojisMap.put(0x0404, R.drawable.tt0404);
        sEmojisMap.put(0x0405, R.drawable.tt0405);
        sEmojisMap.put(0x0406, R.drawable.tt0406);
        sEmojisMap.put(0x0407, R.drawable.tt0407);
        sEmojisMap.put(0x0408, R.drawable.tt0408);
        sEmojisMap.put(0x0409, R.drawable.tt0409);
        sEmojisMap.put(0x0410, R.drawable.tt0410);

        //TattosDoc

        sEmojisMap.put(0x0101, R.drawable.tt0101);
        sEmojisMap.put(0x0102, R.drawable.tt0102);
        sEmojisMap.put(0x0103, R.drawable.tt0103);
        sEmojisMap.put(0x0104, R.drawable.tt0104);
        sEmojisMap.put(0x0105, R.drawable.tt0105);
        sEmojisMap.put(0x0106, R.drawable.tt0106);
        sEmojisMap.put(0x0107, R.drawable.tt0107);
        sEmojisMap.put(0x0108, R.drawable.tt0108);
        sEmojisMap.put(0x0109, R.drawable.tt0109);
        sEmojisMap.put(0x0110, R.drawable.tt0110);




    }

    private static boolean isSoftBankEmoji(char c) {
        return ((c >> 12) == 0xe);
    }

    private static int getEmojiResource(Context context, int codePoint) {
        return sEmojisMap.get(codePoint);
    }

    private static int getSoftbankEmojiResource(char c) {
        return sSoftbanksMap.get(c);
    }

    /**
     * Convert emoji characters of the given Spannable to the according emojicon.
     *
     * @param context
     * @param text
     * @param emojiSize
     */
    public static void addEmojis(Context context, Spannable text, int emojiSize, int textSize) {
        addEmojis(context, text, emojiSize, textSize, 0, -1, false);
    }

    /**
     * Convert emoji characters of the given Spannable to the according emojicon.
     *
     * @param context
     * @param text
     * @param emojiSize
     * @param index
     * @param length
     */
    public static void addEmojis(Context context, Spannable text, int emojiSize, int textSize, int index, int length) {
        addEmojis(context, text, emojiSize, textSize, index, length, false);
    }

    /**
     * Convert emoji characters of the given Spannable to the according emojicon.
     *
     * @param context
     * @param text
     * @param emojiSize
     * @param useSystemDefault
     */
    public static void addEmojis(Context context, Spannable text, int emojiSize, int textSize, boolean useSystemDefault) {
        addEmojis(context, text, emojiSize, textSize, 0, -1, useSystemDefault);
    }

    /**
     * Convert emoji characters of the given Spannable to the according emojicon.
     *
     * @param context
     * @param text
     * @param emojiSize
     * @param index
     * @param length
     */
    public static void addEmojis(Context context, Spannable text, int emojiSize, int textSize, int index, int length, boolean useSystemDefault) {

        int textLength = text.length();
        int textLengthToProcessMax = textLength - index;
        int textLengthToProcess = length < 0 || length >= textLengthToProcessMax ? textLength : (length+index);

        // remove spans throughout all text
        EmojiconSpan[] oldSpans = text.getSpans(0, textLength, EmojiconSpan.class);
        for (int i = 0; i < oldSpans.length; i++) {
            text.removeSpan(oldSpans[i]);
        }

        int skip;
        for (int i = index; i < textLengthToProcess; i += skip) {
            skip = 0;
            int icon = 0;
            char c = text.charAt(i);
            if (isSoftBankEmoji(c)) {
                icon = getSoftbankEmojiResource(c);
                skip = icon == 0 ? 0 : 1;
            }

            if (icon == 0) {
                int unicode = Character.codePointAt(text, i);
                skip = Character.charCount(unicode);

                if (unicode > 0xff) {
                    icon = getEmojiResource(context, unicode);
                }

                if (icon == 0 && i + skip < textLengthToProcess) {
                    int followUnicode = Character.codePointAt(text, i + skip);
                    if (followUnicode == 0x20e3) {
                        int followSkip = Character.charCount(followUnicode);
                        switch (unicode) {
                            case 0x0501:
                                icon = R.drawable.tt0501;
                                break;
                            case 0x0502:
                                icon = R.drawable.tt0502;
                                break;
                            case 0x0503:
                                icon = R.drawable.tt0503;
                                break;
                            case 0x0504:
                                icon = R.drawable.tt0504;
                                break;
                            case 0x0505:
                                icon = R.drawable.tt0505;
                                break;
                            case 0x0506:
                                icon = R.drawable.tt0506;
                                break;
                            case 0x0507:
                                icon = R.drawable.tt0507;
                                break;

                            default:
                                followSkip = 0;
                                break;
                        }
                        skip += followSkip;
                    } else {
                        int followSkip = Character.charCount(followUnicode);
                        switch (unicode) {
                            case 0x0201:
                                icon = (followUnicode == 0x0201) ? R.drawable.tt0201 : 0;
                                break;
                            case 0x0202:
                                icon = (followUnicode == 0x0202) ? R.drawable.tt0202 : 0;
                                break;
                            case 0x0203:
                                icon = (followUnicode == 0x0203) ? R.drawable.tt0203 : 0;
                                break;
                            case 0x0204:
                                icon = (followUnicode == 0x0204) ? R.drawable.tt0204 : 0;
                                break;
                            case 0x0205:
                                icon = (followUnicode == 0x0205) ? R.drawable.tt0205 : 0;
                                break;
                            case 0x0206:
                                icon = (followUnicode == 0x0206) ? R.drawable.tt0206 : 0;
                                break;
                            case 0x0207:
                                icon = (followUnicode == 0x0207) ? R.drawable.tt0207 : 0;
                                break;
                            case 0x0208:
                                icon = (followUnicode == 0x0208) ? R.drawable.tt0208 : 0;
                                break;

                            default:
                                followSkip = 0;
                                break;
                        }
                        skip += followSkip;
                    }
                }
            }

            if (icon > 0) {
                text.setSpan(new EmojiconSpan(context, icon, emojiSize, textSize), i, i + skip, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }
    }
}
